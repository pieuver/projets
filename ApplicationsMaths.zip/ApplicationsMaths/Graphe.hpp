//
//  Graphe.hpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 30/05/2019.
//  Copyright © 2019 yacque. All rights reserved.

#ifndef Graphe_hpp
#define Graphe_hpp

#include <stdio.h>
#include "MatriceCarree.hpp"

class Graphe : public MatriceCarree
{
protected:
    float minimum(float a, float b);
public:
    void FloydWarshall();
    Graphe();
};

#endif /* Graphe_hpp */
