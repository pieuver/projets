//
//  FonctionDiscrete.cpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 15/01/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#include "FonctionDiscrete.hpp"


