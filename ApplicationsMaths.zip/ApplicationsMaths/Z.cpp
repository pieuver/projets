//
//  Z.cpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 28/04/2021.
//  Copyright © 2021 yacque. All rights reserved.
//

#include "Z.hpp"

using namespace std;

int sgn(int x)
{
    if(x>=0)
        return 1;
    return -1;
}

int max_abs(int a, int b)
{
    if(abs(a)>abs(b))
        return a;;
    return b;;
}
int min_abs(int a, int b)
{
    if(abs(a)<abs(b))
        return a;;
    return b;
}
int division_euclidienne(int a,int b)
{
    int q,r;
    int A=a; // car a joue le role de an
    int B=b;
    if(abs(a) <abs(b)){
        q = 0;
        r = a;
        
    }
    else{
        q = 1;
        r=a-b;
        
    do{
       // printf("%d - %d = %d\n",a,b,r);
        
        a = max_abs(r,b);
        b=min_abs(r,b);
        r = a-sgn(a*b)*b;
        q+=sgn(a*b);
        printf("%d = %dx%d + %d\n",a,b,q,r);

    }while (abs(r)>=abs(b) && r!=0);

    
    }
    printf("%d = %dx%d + %d\n",A,B,q,r);
    return 0;

}
int suite_n_ieme(int *a,int *b, int n)
{
     *a= 0;
    * b =0;
    for(int i = 0; i< n;i++)
    {
        *a*=10;
        *a+=i;
        if(i<n-1){
        *b*=10;
        *b+=i;

            
        }
    }
    return 0;
}
