//
//  Foncteur.hpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 23/01/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#ifndef Foncteur_hpp
#define Foncteur_hpp

#include <stdio.h>
#include <vector>
class Foncteur
{
private:
    void *objet;
    int tailleX;
    int tailleY;
    
};

#endif /* Foncteur_hpp */
