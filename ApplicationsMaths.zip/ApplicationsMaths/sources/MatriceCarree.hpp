
#ifndef MatriceCarree_hpp
#define MatriceCarree_hpp

#include <stdio.h>
#include "Matrice.hpp"
#define I(n) MatriceCarree(n)
class MatriceCarree : public Matrice
{
public:
    MatriceCarree();
    MatriceCarree(const std::string &M);
    MatriceCarree(const MatriceCarree &la);
    MatriceCarree(int n);
    MatriceCarree rotation();
    MatriceCarree symetrie();
 
    MatriceCarree(const Matrice & la);
    MatriceCarree operator+(const MatriceCarree &la);
    MatriceCarree operator-(const MatriceCarree &la);
    MatriceCarree operator*(const MatriceCarree &la);
    MatriceCarree operator*(float coefficient);
    MatriceCarree sousMatrice(int ligne, int colonne);
    MatriceCarree coMatrice();
    float determinant();
    MatriceCarree inverse();
    MatriceCarree transposee();
    
    void decris(); // procedure qui decrit la matrice : elle donne la matrice, affiche le det, la trace
    float trace();
    bool orthogonale();
    bool inversible();
    
    
};
MatriceCarree operator*(float coefficient, const MatriceCarree &la);
enum {SYMETRIE, ROTATION,};
#endif /* MatriceCarree_hpp */
