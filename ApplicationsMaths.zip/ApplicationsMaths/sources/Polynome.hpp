
#ifndef Polynome_hpp
#define Polynome_hpp

#include <stdio.h>
#include <vector>
#include <iostream>

float puissanceEntiere(float valeur, unsigned int exposant);


typedef struct Monome {
    int degre;
    float multiplicateur;
    Monome * suivante;
    
}Monome;
void ajoute_tete(Monome *A, Monome *B);
void ajoute_queue(Monome *A, Monome *B);

void catMonome(Monome *A, Monome *B);
class Polynome
{
    /*
     C'est une liste chainee
     */
private:
    Monome* P;
    
    Monome * getDerniereCell();
    void trie();
public:
    float valeur(float x);
    void ajouter(float multiplicateur, int degre);
    
    void afficher(); //Affiche un polynome sous la forme de la somme des a,i X,i comme a la maison :)
    
    Polynome();
    ~Polynome();
    
    // Viennent les surcharges des operateurs : je sais que K[X] est un anneau, donc on surcharge + et *
    Polynome operator+(const Polynome & Q);
    Polynome operator*(const Polynome &Q);

};


// Si j'arrive a deriver un polynome, je peux deriver beaucoup de fonctions
Monome * derive_cellule(Monome * cellule);
Polynome derive(Polynome * P);
#endif /* Polynome_hpp */
