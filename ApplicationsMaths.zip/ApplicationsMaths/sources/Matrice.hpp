
#ifndef Matrice_hpp
#define Matrice_hpp

#include <stdio.h>
#include <iostream>
#include <fstream>


class Matrice /*Definition de la classe matrice de longueur et de largeur quelconques, les proprietes elementaires de cette classe sont implementees: addition,soustraction, multiplication.
               */
{
protected:
    unsigned int nombreLignes;
    unsigned int nombreColonnes;
    double **a;
    bool verifieIntegriteFichier(); // pas fait encore
public:
    
    Matrice();
    Matrice(int nombre_lignes, int nombre_colonnes);
    Matrice(const Matrice &la);
    
    friend std::ostream & operator<<(std::ostream & flux,const Matrice &la);
    friend std::istream & operator>>(std::istream & flux, Matrice &la);
    Matrice operator+(const Matrice &la);
    Matrice operator-(const Matrice &la);
    Matrice operator*(const Matrice &la);
    Matrice operator*(float coefficient);
    Matrice (const std::string & M);
    Matrice transposee();
    
    Matrice & operator=(const Matrice &la);
    bool operator==(const Matrice &la);
    unsigned int getNombreLignes() const;
    unsigned int getNombreColonnes() const;
    double getCoefficient(unsigned int i,unsigned int j);
    void setCoefficient(unsigned int i,unsigned int j, double coefficient);
    
    ~Matrice();
    
};

Matrice operator*(float coefficient, const Matrice &la);
Matrice operator-(const Matrice &la);

#endif
