#include <iostream>
#include "Graphe.hpp"
#include "Polynome.hpp"
#include "Integrale.hpp"
#include "Z.hpp"
#include <math.h>
using namespace std;

float carre(float x)
{
    return x*x;
}

float identite(float x)
{
    return x;
}
float gaussienne(float x)
{
    float pi = M_PI;
    float racine_pi = sqrt(2*pi);
    return (1.0/racine_pi)*exp(-0.5*carre(x));
}
float exp_exo(float x)
{
    return cos(x)*exp(-x);
}
float cos_carre(float x)
{
    return cos(x)*cos(x);
}


int main(int argc, const char * argv[]) {
    
    Polynome P;
    Polynome Q;
    
    Monome X;
    X.degre = 1;
  
    P.ajouter(1, 3);
    P.ajouter(1, 1);

    P.afficher();

    return 0;
}

