
#include "Polynome.hpp"

using namespace std;

float puissanceEntiere(float valeur, unsigned int exposant){
    if(exposant==0)
        return 1;
    else if(exposant == 1)
        return valeur;
    else
        return valeur*puissanceEntiere(valeur,exposant-1);
}

Polynome::Polynome()
{
    P = new Monome;
    P->degre = 1;
    P->multiplicateur=1;
    P->suivante=NULL;

}

void Polynome::afficher()
{
    Monome *cellule_courante = P;
    while (cellule_courante !=NULL) {
        if(cellule_courante->multiplicateur != 1)
        cout<<cellule_courante->multiplicateur;
        cout<<"X";
        cout<<"^"<<cellule_courante->degre;
        if(cellule_courante->suivante != NULL)
            cout<<" + ";
        
        cellule_courante = cellule_courante->suivante;
    }
    cout<<endl;
}
Monome * Polynome::getDerniereCell(){
    Monome * cellule_courante = P;
    while(cellule_courante->suivante != NULL)
    {
        if(cellule_courante->suivante != NULL)
        cellule_courante = cellule_courante->suivante;
    }
    return cellule_courante;
}
void Polynome::ajouter(float multiplicateur, float degre)
{
    

    
    Monome * cellule_courante = P;
    while (cellule_courante != NULL) {
        if(cellule_courante->degre == degre){
            cellule_courante->multiplicateur+=multiplicateur;
            return;
        }
        cellule_courante=cellule_courante->suivante;

    }
   
    cellule_courante=getDerniereCell();
    Monome * nouvelle;
    nouvelle = new Monome;
    nouvelle->multiplicateur=multiplicateur;
    nouvelle->degre = degre;
    nouvelle->suivante=NULL;
    cellule_courante->suivante = nouvelle;
}

float Polynome::valeur(float x)
{
    /*
     C'est le calculateur du polynome a une valeur V, cela correspond, pour un polynome P a faire P(V)
     */;
    Monome * cellule_courante = P;
    float resultat = 0;
    while(cellule_courante != NULL)
    {
        resultat+=cellule_courante->multiplicateur*puissanceEntiere(x, cellule_courante->degre);
        cellule_courante=cellule_courante->suivante;
    }
    return resultat;
}

Polynome::~Polynome(){
    P=NULL;
}

Monome * derive_cellule(Monome *cellule)
{
    Monome * resultat = new Monome;
    resultat->suivante=NULL;
    if(cellule->degre >= 1)
    {
        resultat->multiplicateur=cellule->degre*cellule->multiplicateur;
        resultat->degre=cellule->degre-1;
    }
    else{
        resultat->multiplicateur = 0;
        resultat->degre = 0;
    }
    return resultat;
    
}
