
#include "Cplx.hpp"

Cplx::Cplx()
{
    im = 0;
    re = 0;
}
nombre Cplx::Re(){
    return re;
}
nombre Cplx::Im() {return im;}
nombre Cplx::module() {return sqrt(re*re + im*im);}
