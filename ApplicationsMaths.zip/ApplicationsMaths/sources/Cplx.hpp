

#ifndef NombreComplexe_hpp
#define NombreComplexe_hpp

#include <stdio.h>
#include <iostream>
#include <math.h>
typedef double nombre;
class Cplx
{
    /* classe nombre complexe  */
private:
    nombre re;
    nombre im;
    
public:
    
    nombre module();
    nombre argument();
    Cplx operator*(const Cplx &le);
    Cplx operator+(const Cplx &le);
    Cplx operator/(const Cplx &le);
    Cplx operator-(const Cplx &le);
    
    Cplx();
    Cplx(float re, float im);
    Cplx(const Cplx &le);
    friend std::ostream& operator<<(std::ostream &flux, const Cplx &le);
    friend std::istream& operator>>(std::istream &flux, Cplx &le);
    nombre Re();
    nombre Im();
    ~Cplx();
};
#endif /* NombreComplexe_hpp */
