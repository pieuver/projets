
#include "MatriceCarree.hpp"
#include <fstream>
#include <vector>
#include <assert.h>
using namespace std;
MatriceCarree::MatriceCarree():Matrice(3,3){}
MatriceCarree::MatriceCarree(int n):Matrice(n,n)
{
    for(int i = 0; i <n; i++)
    {
        for(int j = 0; j <n;j++)
        {
            if(i == j)
                a[i][j] = 1;
            else a[i][j]=0;
        }
    }
}

MatriceCarree::MatriceCarree(const MatriceCarree &la):Matrice(la)
{
    
}

MatriceCarree MatriceCarree::operator+(const MatriceCarree &la){
    MatriceCarree resultat(la.nombreColonnes);
    if(la.nombreColonnes == nombreLignes && la.nombreLignes ==nombreColonnes)
    {
        
        for(int i = 0; i< nombreLignes; i++)
        {
            for(int j =0; j< nombreColonnes;j++)
            {
                resultat.a[i][j]= a[i][j]+la.a[i][j];
            }
        }
        
    }
    else{
        cout<<"Erreur dans la somme de "<<*this<<" et"<<la<<endl;
    }
    return resultat;
}
MatriceCarree MatriceCarree::operator-(const MatriceCarree &la){
    MatriceCarree resultat(la.nombreColonnes);
    if(la.nombreColonnes == nombreLignes && la.nombreLignes ==nombreColonnes)
    {
        
        for(int i = 0; i< nombreLignes; i++)
        {
            for(int j =0; j< nombreColonnes;j++)
            {
                resultat.a[i][j]= a[i][j]-la.a[i][j];
            }
        }
        
    }
    else{
        cout<<"Erreur dans la somme de "<<*this<<" et"<<la<<endl;
    }
    return resultat;
}

MatriceCarree MatriceCarree::operator*(const MatriceCarree &la)
{
    MatriceCarree resultat(la.nombreColonnes);
    double calcul = 0;
    if(nombreLignes == la.nombreColonnes )
    {
        for(int i = 0; i < nombreLignes; i++){
            for(int j = 0; j < la.nombreColonnes; j++)
            {
                for(int k = 0; k< nombreColonnes;k++)
                    calcul+=a[i][k]*la.a[k][j];
                resultat.a[i][j] = calcul;
                calcul = 0;
            };
        }
    }
    return resultat;
}

MatriceCarree MatriceCarree::operator*(float coefficient){
    MatriceCarree resultat(*this);
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j <nombreColonnes;j++)
        {
            if(resultat.a[i][j]!=0)
            resultat.a[i][j] = coefficient*resultat.a[i][j];
        }
    }
    return resultat;
}

MatriceCarree MatriceCarree::sousMatrice(int ligne, int colonne)
{
    
    assert(nombreLignes > 2 &&nombreColonnes >2);
    
    MatriceCarree resultat(nombreLignes-1);
    int k = 0;
    int l = 0;
    if(nombreLignes <=2)
    {
        resultat.setCoefficient(0, 0, a[0][0]);
        return resultat;
    }
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j < nombreColonnes;j++)
        {
            if(i!= ligne && j!=colonne){
                resultat.a[k][l] = a[i][j];
                l++;
                if(l>=nombreColonnes-1){
                    l= 0;
                    k++;
                }
                
            }
        }
    }
    return resultat;
}

MatriceCarree operator*(float coefficient, const MatriceCarree &la)
{
    MatriceCarree resultat(la);
    for(int i = 0; i < la.getNombreLignes(); i++)
    {
        for(int j = 0; j < la.getNombreColonnes(); j++)
        {
            if(resultat.getCoefficient(i, j) != 0)
                resultat.setCoefficient(i, j, coefficient*resultat.getCoefficient(i,j));
        }
    }
    return resultat;
}

float MatriceCarree::determinant(){
    float determinant = 0;
    if(nombreLignes == 2 && nombreColonnes ==2)
        determinant = a[0][0]*a[1][1]-a[0][1]*a[1][0];
    else
    {
        for(int j = 0; j< nombreColonnes; j++)
        {
            /**
             On choisit de faire un developpement par rapport a la premiere ligne
             */
            float coefficient = a[0][j];
            if(j%2==0)
                determinant+=coefficient*sousMatrice(0, j).determinant();
            else
                determinant-=coefficient*sousMatrice(0, j).determinant();

        }
    }
    return determinant;
}
float MatriceCarree::trace(){
    float resultat = 0;
    for(int i = 0; i < nombreLignes; i++)
        resultat+=a[i][i];
    return resultat;
}
bool MatriceCarree::orthogonale()
{
    if(this->transposee()*(*this) == I(nombreLignes))
        return true;
    return false;
}
bool MatriceCarree::inversible()
{
    return (determinant()!= 0);
}
MatriceCarree MatriceCarree::coMatrice()
{
    MatriceCarree coMatrice(nombreLignes);
    int signe= 1;
    if(nombreLignes == 2 && nombreLignes==2)
    {
        float A,B,C,D;
        A=a[0][0];
        B=a[0][1];
        C=a[1][0];
        D=a[1][1];
        
        coMatrice.setCoefficient(0, 0, D);
        coMatrice.setCoefficient(0, 1, -C);
        coMatrice.setCoefficient(1, 0, -B);
        coMatrice.setCoefficient(1, 1, A);
        return coMatrice;
        

        
    }
        
    for(int i = 0; i <nombreLignes; i++)
    {
        for(int j = 0; j  < nombreColonnes;j++)
        {
            MatriceCarree A= sousMatrice(i, j);
            float resultat = signe*A.determinant();
            coMatrice.setCoefficient(i, j, resultat);
            signe*=(-1);
        }
        signe*=(-1);

    }
    return coMatrice;
}
MatriceCarree::MatriceCarree(const Matrice &la)
{
    if(la.getNombreLignes()==la.getNombreColonnes())
    {
        MatriceCarree resultat(la.getNombreLignes());
        resultat=la;
        /*for(int i = 0; i <resultat.nombreLignes;i++)
        {
            for(int j = 0; j < la.getNombreColonnes();j++)
            {
                resultat.a[i][j] = la.a[i][j];
            }
        }*/
        *this = resultat;
        
        
    }
    else
    {
        
    }
}
MatriceCarree MatriceCarree::inverse(){
    assert(determinant()!=0);
    float inverse_determinant = 1.0/determinant();
    MatriceCarree inverse(coMatrice());
    inverse = inverse_determinant*inverse.transposee();
   
    return inverse;
}

MatriceCarree::MatriceCarree(const string &M)
/*
 Necessite a la fin que les lignes = colonnes (matrice carree)
 */
{
    nombreLignes = 2;
    nombreColonnes = 2;
    a = new double * [2];
    for(int i =0; i< 2; i++)
    {
        a[i] = new double [2];
    }
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j< nombreColonnes; j++)
        {
            if(i!=j)
                a[i][j] = 0;
            else
                a[i][j]=1;
        }
    }
    
    ifstream fichier;
    fichier.open(M.c_str());
    std::vector<float> coefficients;
    float coefficient = 0;
    if(fichier.is_open())
    {
        
        int nb_lignes = 1;
        int nb_colonnes = 1;
        
        char c = '\0';
        while (!fichier.eof()) {
            fichier.get(c);
            fichier.putback(c);
            fichier>>coefficient;
            coefficients.push_back(coefficient);
            if(c == '\n')
                nb_lignes++;
            if(c== ' ' && nb_lignes==1)
                nb_colonnes++;
        }
        nombreLignes = nb_lignes;
        nombreColonnes = nb_colonnes;
        if(nombreLignes != nombreColonnes)
        {
            cout<<"Erreur dans l'ouverture du fichier : "<<M<<" La matrice n'est pas carree !"<<endl;
            exit(1);
        }
        /*Allocation de la matrice*/
        a = new double * [nombreLignes];
        for(int i = 0; i< nombreLignes; i++)
            a[i] = new double[nombreColonnes];
        
        for(int k = 0; k<coefficients.size();k++)
        {
            int i = k/nombreColonnes;
            int j = k%nombreColonnes;
            
            
            a[i][j]= coefficients[k];
        }
    }
    cout<<"Matrice : "<<M<<" ouverte avec succes !"<<endl;

}
void MatriceCarree::decris()
{
    cout<<*this<<endl<<"Det = "<< determinant() <<endl<<"Tr = "<<trace()<<endl<<"transposee = "<<endl<<transposee()<< endl;
}
MatriceCarree MatriceCarree::transposee(){
    MatriceCarree matrice(*this);
    for(int i = 0; i < nombreLignes;i++)
    {
        for(int j = 0; j < nombreColonnes;j++)
        {
            matrice.a[i][j]=getCoefficient(j,i);
        }
    }
    return matrice;
}
