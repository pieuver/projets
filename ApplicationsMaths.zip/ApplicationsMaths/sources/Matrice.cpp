#include "Matrice.hpp"
#include <vector>
using namespace std;

Matrice::Matrice()
{
    nombreLignes = 2;
    nombreColonnes = 2;
    a = new double * [2];
    for(int i =0; i< 2; i++)
    {
        a[i] = new double [2];
    }
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j< nombreColonnes; j++)
        {
            if(i!=j)
                a[i][j] = 0;
            else
                a[i][j]=1;
        }
    }
}

Matrice::Matrice(int nombre_lignes, int nombre_colonnes)
{
    nombreLignes = nombre_lignes;
    nombreColonnes = nombre_colonnes;
    a = new double* [nombre_lignes];
    for(int i = 0; i < nombre_lignes; i++)
    {
        a[i] = new double [nombre_colonnes];
        for(int j = 0; j< nombreColonnes;j++)
            a[i][j] = 0;
    }
}
Matrice::Matrice(const Matrice &la)
{
    nombreLignes = la.nombreLignes;
    nombreColonnes= la.nombreColonnes;
    a = new double * [nombreLignes];
    for(int i = 0; i <nombreLignes;i++)
    {
        a[i] = new double[nombreColonnes];
        for(int j = 0; j < nombreColonnes;j++)
        {
            a[i][j]= la.a[i][j];
        }
    }
}
Matrice::~Matrice()
{
    for(int i = 0; i< nombreLignes; i++)
    {
        delete [] a[i];
        a[i] = NULL;
    }
    delete [] a;
    a = NULL;
}
std::ostream & operator<<(std::ostream & flux, const Matrice &la)
{
    for(int i = 0; i< la.nombreLignes;i++)
    {
        for(int j = 0; j< la.nombreColonnes;j++)
            flux<<la.a[i][j]<<" ";
        flux<<endl;

    }
    return flux;
}

std::istream & operator>>(std::istream &flux,  Matrice &la)
{
    
    for(int i = 0; i< la.nombreLignes;i++)
    {
        for(int j = 0; j< la.nombreColonnes;j++)
            flux>>la.a[i][j];
        
    }
    return flux;
}

Matrice Matrice::operator+(const Matrice &la)
{
    Matrice resultat(la.nombreColonnes,la.nombreLignes);
    if(la.nombreColonnes == nombreColonnes && la.nombreLignes ==nombreLignes)
    {
        
        for(int i = 0; i< nombreLignes; i++)
        {
            for(int j =0; j< nombreColonnes;j++)
            {
                resultat.a[i][j]= a[i][j]+la.a[i][j];
            }
        }
        
    }
    else{
        cout<<"Erreur dans la somme de "<<*this<<" et"<<la<<endl;
    }
    return resultat;
};


Matrice Matrice::operator-(const Matrice &la)
{
    Matrice resultat;
    
    if(la.nombreColonnes == nombreColonnes && la.nombreLignes ==nombreLignes)
    {
        for(int i = 0; i< nombreLignes; i++)
        {
            for(int j =0; j< nombreColonnes;j++)
            {
                resultat.a[i][j]= a[i][j]-la.a[i][j];
            }
        }
        
    }
    else{
        cout<<"Erreur dans la difference de "<<*this<<" et"<<la<<endl;
    }
    return resultat;
};

Matrice & Matrice::operator=(const Matrice &la)
{
    if (nombreLignes==la.nombreLignes && nombreColonnes==la.nombreColonnes)
    {
        for(int i = 0; i < nombreLignes; i++)
        {
            for(int j =0; j< nombreColonnes;j++)
                a[i][j] = la.a[i][j];
        }
    }
    else
    {
        for(int i = 0; i< nombreLignes; i++)
        {
            delete [] a[i];
            a[i] = NULL;
        }
        delete [] a;
        a = NULL;
        a = new double* [la.nombreLignes];
        nombreLignes= la.nombreLignes;
        nombreColonnes = la.nombreColonnes;
        for(int i = 0; i< nombreLignes; i++)
        {
            a[i]= new double [nombreColonnes];

            for(int j = 0; j< nombreColonnes;j++)
            {
                a[i][j] = la.a[i][j];
            }
        }
    }
    return *this;
    
}

Matrice Matrice::operator*(const Matrice &la)
{
    Matrice resultat(nombreLignes, la.nombreColonnes);
    double calcul = 0;
    if(nombreLignes == la.nombreColonnes )
    {
        for(int i = 0; i < nombreLignes; i++){
            for(int j = 0; j < la.nombreColonnes; j++)
            {
                for(int k = 0; k< nombreColonnes;k++)
                    calcul+=a[i][k]*la.a[k][j];
                resultat.a[i][j] = calcul;
                calcul = 0;
            };
        }
    }
    return resultat;
}
void Matrice::setCoefficient(unsigned int i, unsigned int j, double coefficient)
{
    /**
     Visiblement l'ordinateur fait la difference entre 0 et -0, par consequent on décrète que si le coefficient est nul, on dit que a[i][j] = 0 et non -0 
     */
    if(coefficient == 0.0f)
        a[i][j] = 0;
    else
        a[i][j] = coefficient;
}
bool Matrice::operator==(const Matrice &la)
{
    if(la.nombreColonnes != nombreColonnes || la.nombreLignes != nombreLignes)
        return false;
    int compteur = 0;

    
        for(int i = 0; i < nombreLignes;i++)
        {
            for(int j = 0; j< nombreColonnes; j++)
            {
                if(la.a[i][j]==a[i][j])
                    compteur++;
            }
        }
    
    return compteur==nombreLignes*nombreColonnes;
}
Matrice::Matrice(const std::string &M)
{
    nombreLignes = 2;
    nombreColonnes = 2;
    a = new double * [2];
    for(int i =0; i< 2; i++)
    {
        a[i] = new double [2];
    }
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j< nombreColonnes; j++)
        {
            if(i!=j)
                a[i][j] = 0;
            else
                a[i][j]=1;
        }
    }
    
    ifstream fichier;
    fichier.open(M.c_str());
    std::vector<float> coefficients;
    float coefficient = 0;
    if(fichier.is_open())
    {
   
        int nb_lignes = 1;
        int nb_colonnes = 1;

        char c = '\0';
        while (!fichier.eof()) {
            fichier.get(c);
            fichier.putback(c);
            fichier>>coefficient;
            coefficients.push_back(coefficient);
            if(c == '\n')
                nb_lignes++;
            if(c== ' ' && nb_lignes==1)
                nb_colonnes++;
        }
        nombreLignes = nb_lignes;
        nombreColonnes = nb_colonnes;
        /*Allocation de la matrice*/
        a = new double * [nombreLignes];
        for(int i = 0; i< nombreLignes; i++)
            a[i] = new double[nombreColonnes];
       
        for(int k = 0; k<coefficients.size();k++)
        {
            int i = k/nombreColonnes;
            int j = k%nombreColonnes;

      
            a[i][j]= coefficients[k];
        }
    }
}
Matrice Matrice::operator*(float coefficient)
{
    Matrice resultat(*this);
    for(int i = 0; i < nombreLignes; i++)
    {
        for(int j = 0; j < nombreColonnes; j++)
        {
            if(resultat.a[i][j] != 0)
                resultat.a[i][j] = coefficient*resultat.a[i][j];
        }
    }
    return resultat;
}
Matrice operator*(float coefficient, const Matrice &la)
{
    Matrice resultat(la);
    for(int i = 0; i < la.getNombreLignes(); i++)
    {
        for(int j = 0; j < la.getNombreColonnes(); j++)
        {
            if(resultat.getCoefficient(i, j) != 0)
                resultat.setCoefficient(i, j, coefficient*resultat.getCoefficient(i,j));
        }
    }
    return resultat;
}
Matrice operator-(const Matrice &la)
{
    Matrice resultat(la);
    for(int i = 0; i < la.getNombreLignes(); i++)
    {
        for(int j = 0; j < la.getNombreColonnes(); j++)
        {
            if(resultat.getCoefficient(i, j) != 0)
                resultat.setCoefficient(i, j, -resultat.getCoefficient(i,j));
        }
    }
    return resultat;
}
unsigned int Matrice::getNombreLignes() const {return  nombreLignes;}
unsigned int Matrice::getNombreColonnes() const {return  nombreColonnes;}
double Matrice::getCoefficient(unsigned int i, unsigned int j){return a[i][j];}


Matrice Matrice::transposee(){
    Matrice resultat(nombreColonnes,nombreLignes);
    for(int i = 0; i< nombreLignes;i++)
    {
        for(int j = 0; j< nombreColonnes;j++)
            resultat.a[j][i]=a[i][j];
    }
    return resultat;
}
