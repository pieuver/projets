//
//  fonctions.cpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 17/11/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#include "fonctions.hpp"
