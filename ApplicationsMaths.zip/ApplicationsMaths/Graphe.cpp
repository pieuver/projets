//
//  Graphe.cpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 30/05/2019.
//  Copyright © 2019 yacque. All rights reserved.
//

#include "Graphe.hpp"
#define infini 1.0f/0.0f
using namespace std;
float Graphe::minimum(float a, float b)
{
    
    if(a<b)
        return a;
    return b;
    
   
}
Graphe::Graphe():MatriceCarree(5)
{
    for(int i = 0; i< nombreLignes; i++)
    {
        for(int j = 0; j < nombreColonnes; j++)
            setCoefficient(i, j, 1);
    }
}
void Graphe::FloydWarshall()
{
    MatriceCarree Ak = *this;
    bool inf = false;
    int k = 0;
    cout<<"A "<<k<<endl;
    cout<<Ak;
    do {
        inf = false;
    for(int i = 0; i< nombreLignes; i++)
    {
        for(int j = 0; j <nombreColonnes; j++)
        {
            if(getCoefficient(i, j) == infini)
                inf = true;
        }
    }
        for(int i = 0; i < nombreLignes; i++)
        {
            for(int j = 0; j <nombreColonnes; j++)
            {
                Ak.setCoefficient(i, j, minimum(Ak.getCoefficient(i, j), Ak.getCoefficient(i, k) +Ak.getCoefficient(k, j)));
            }
        }
        k++;
        cout<<"A "<<k<<endl;
        
    }while (k<nombreLignes);
    
    
};
