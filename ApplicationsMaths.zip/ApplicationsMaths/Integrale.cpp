//
//  Integrale.cpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 17/11/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#include "Integrale.hpp"
#include <iostream>
using namespace std;

float integrale_rectangle(float a, float b, float (*fonction)(float) )
{
    
    float resultat =0.0f;
    if(a<b)
    {
        /// La methode des rectangles
        for(int k = 0; k<=N; k++){
            resultat+=fonction(a + (float)k*(b-a)/N)*(b-a)/N;
            
        }
        return resultat;
    }
    
    return -integrale_rectangle(b, a, fonction);
}
