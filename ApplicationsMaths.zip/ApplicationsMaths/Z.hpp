//
//  Z.hpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 28/04/2021.
//  Copyright © 2021 yacque. All rights reserved.
//

#ifndef Z_hpp
#define Z_hpp

#include <stdio.h>
#include <math.h>
#include <iostream>

int division_euclidienne(int a,int b);
int suite_n_ieme(int *a,int *b, int n);
int sgn(int x);
#endif /* Z_hpp */
