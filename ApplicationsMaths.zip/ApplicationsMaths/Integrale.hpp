//
//  Integrale.hpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 17/11/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#ifndef Integrale_hpp
#define Integrale_hpp

#include <stdio.h>
#include "fonctions.hpp"
#define N 1000000

class Integrale
{
    float a;
    float b;
    
    float getA();
    float getB();
    void set_a(float A);
    void set_b(float B);
    
};
float integrale_rectangle(float a, float b, float (*fonction)(float) );
#endif /* Integrale_hpp */
