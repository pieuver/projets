//
//  FonctionDiscrete.hpp
//  ApplicationsMaths
//
//  Created by Mebarka Kouchida on 15/01/2020.
//  Copyright © 2020 yacque. All rights reserved.
//

#ifndef FonctionDiscrete_hpp
#define FonctionDiscrete_hpp

#include <stdio.h>

#endif /* FonctionDiscrete_hpp */
